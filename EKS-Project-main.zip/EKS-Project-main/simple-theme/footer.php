<footer>
    <p>&copy; <?php echo date('Y'); ?> My Simple WordPress Theme-got it</p>
</footer>

<?php wp_footer(); ?>
</body>
</html>
