<?php
/**
 * Title: Team with image, text, social icons.
 * Slug: edublock/general-team-two-columns
 * Categories: edublock-general
 * Viewport Width: 1280
 */
?>

<!-- wp:group {"layout":{"type":"constrained"}} -->
<div class="wp-block-group"><!-- wp:group {"layout":{"type":"default"}} -->
<div class="wp-block-group"><!-- wp:spacer -->
<div style="height:100px" aria-hidden="true" class="wp-block-spacer"></div>
<!-- /wp:spacer -->

<!-- wp:paragraph {"textColor":"primary"} -->
<p class="has-primary-color has-text-color">OUR TEAM</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"fontSize":"max-48"} -->
<h2 class="has-max-48-font-size">Meet the<br>Team</h2>
<!-- /wp:heading -->

<!-- wp:spacer {"height":"71px"} -->
<div style="height:71px" aria-hidden="true" class="wp-block-spacer"></div>
<!-- /wp:spacer -->

<!-- wp:spacer {"height":"0px"} -->
<div style="height:0px" aria-hidden="true" class="wp-block-spacer"></div>
<!-- /wp:spacer -->

<!-- wp:columns -->
<div class="wp-block-columns"><!-- wp:column {"style":{"spacing":{"padding":{"top":"0","right":"0","bottom":"0","left":"0"}},"border":{"width":"0px","style":"none"}},"className":"is-style-default"} -->
<div class="wp-block-column is-style-default" style="border-style:none;border-width:0px;padding-top:0;padding-right:0;padding-bottom:0;padding-left:0"><!-- wp:image {"id":115,"sizeSlug":"full","linkDestination":"none"} -->
<figure class="wp-block-image size-full"><img src="<?php echo esc_url( get_theme_file_uri() ) . '/assets/images/'; ?>t1.png" alt="" class="wp-image-115"/></figure>
<!-- /wp:image -->

<!-- wp:heading -->
<h2>Jimmy Banh</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Co-founder / CEO</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Successfully completed Project 8, demonstrating strong skills in cloud infrastructure and deployment using Amazon EKS.</p>
<!-- /wp:paragraph -->

<!-- wp:social-links {"iconColor":"lightgrey","iconColorValue":"#6C6C77","className":"is-style-logos-only"} -->
<ul class="wp-block-social-links has-icon-color is-style-logos-only"><!-- wp:social-link {"url":"#","service":"linkedin"} /--></ul>
<!-- /wp:social-links --></div>
<!-- /wp:column -->

<!-- wp:column {"style":{"spacing":{"padding":{"top":"0","right":"0","bottom":"0","left":"0"}},"border":{"width":"0px","style":"none"}},"className":"is-style-default"} -->
<div class="wp-block-column is-style-default" style="border-style:none;border-width:0px;padding-top:0;padding-right:0;padding-bottom:0;padding-left:0"><!-- wp:image {"id":117,"sizeSlug":"full","linkDestination":"none"} -->
<figure class="wp-block-image size-full"><img src="<?php echo esc_url( get_theme_file_uri() ) . '/assets/images/'; ?>t2.png" alt="" class="wp-image-117"/></figure>
<!-- /wp:image -->

<!-- wp:heading -->
<h2>Cynthia Howery</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>CCO</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Successfully completed Project 8, demonstrating strong skills in cloud infrastructure and deployment using Amazon EKS.</p>
<!-- /wp:paragraph -->

<!-- wp:social-links {"iconColor":"lightgrey","iconColorValue":"#6C6C77","className":"is-style-logos-only"} -->
<ul class="wp-block-social-links has-icon-color is-style-logos-only"><!-- wp:social-link {"url":"#","service":"linkedin"} /--></ul>
<!-- /wp:social-links --></div>
<!-- /wp:column -->

<!-- wp:column {"style":{"spacing":{"padding":{"top":"0","right":"0","bottom":"0","left":"0"}},"border":{"width":"0px","style":"none"}},"className":"is-style-default"} -->
<div class="wp-block-column is-style-default" style="border-style:none;border-width:0px;padding-top:0;padding-right:0;padding-bottom:0;padding-left:0"><!-- wp:image {"id":118,"sizeSlug":"full","linkDestination":"none"} -->
<figure class="wp-block-image size-full"><img src="<?php echo esc_url( get_theme_file_uri() ) . '/assets/images/'; ?>t3.png" alt="" class="wp-image-118"/></figure>
<!-- /wp:image -->

<!-- wp:heading -->
<h2>Leo Palmieri</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>CFO</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Successfully completed Project 8, demonstrating strong skills in cloud infrastructure and deployment using Amazon EKS.</p>
<!-- /wp:paragraph -->

<!-- wp:social-links {"iconColor":"lightgrey","iconColorValue":"#6C6C77","className":"is-style-logos-only"} -->
<ul class="wp-block-social-links has-icon-color is-style-logos-only"><!-- wp:social-link {"url":"#","service":"linkedin"} /--></ul>
<!-- /wp:social-links --></div>
<!-- /wp:column --></div>
<!-- /wp:columns -->

<!-- wp:spacer -->
<div style="height:100px" aria-hidden="true" class="wp-block-spacer"></div>
<!-- /wp:spacer -->

<!-- wp:columns -->
<div class="wp-block-columns"><!-- wp:column {"style":{"spacing":{"padding":{"top":"0","right":"0","bottom":"0","left":"0"}},"border":{"width":"0px","style":"none"}},"className":"is-style-default"} -->
<div class="wp-block-column is-style-default" style="border-style:none;border-width:0px;padding-top:0;padding-right:0;padding-bottom:0;padding-left:0"><!-- wp:image {"id":119,"sizeSlug":"full","linkDestination":"none"} -->
<figure class="wp-block-image size-full"><img src="<?php echo esc_url( get_theme_file_uri() ) . '/assets/images/'; ?>t4.png" alt="" class="wp-image-119"/></figure>
<!-- /wp:image -->

<!-- wp:heading -->
<h2>Randy Phillips</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>COO</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Successfully completed Project 8, demonstrating strong skills in cloud infrastructure and deployment using Amazon EKS.</p>
<!-- /wp:paragraph -->

<!-- wp:social-links {"iconColor":"lightgrey","iconColorValue":"#6C6C77","className":"is-style-logos-only"} -->
<ul class="wp-block-social-links has-icon-color is-style-logos-only"><!-- wp:social-link {"url":"#","service":"linkedin"} /--></ul>
<!-- /wp:social-links --></div>
<!-- /wp:column -->

<!-- wp:column {"style":{"spacing":{"padding":{"top":"0","right":"0","bottom":"0","left":"0"}},"border":{"width":"0px","style":"none"}},"className":"is-style-default"} -->
<div class="wp-block-column is-style-default" style="border-style:none;border-width:0px;padding-top:0;padding-right:0;padding-bottom:0;padding-left:0"><!-- wp:image {"id":120,"sizeSlug":"full","linkDestination":"none"} -->
<figure class="wp-block-image size-full"><img src="<?php echo esc_url( get_theme_file_uri() ) . '/assets/images/'; ?>t5.png" alt="" class="wp-image-120"/></figure>
<!-- /wp:image -->

<!-- wp:heading -->
<h2>Jennie Thompson</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>CLCO</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Successfully completed Project 8, demonstrating strong skills in cloud infrastructure and deployment using Amazon EKS.</p>
<!-- /wp:paragraph -->

<!-- wp:social-links {"iconColor":"lightgrey","iconColorValue":"#6C6C77","className":"is-style-logos-only"} -->
<ul class="wp-block-social-links has-icon-color is-style-logos-only"><!-- wp:social-link {"url":"#","service":"linkedin"} /--></ul>
<!-- /wp:social-links --></div>
<!-- /wp:column -->

<!-- wp:column {"style":{"spacing":{"padding":{"top":"0","right":"0","bottom":"0","left":"0"}},"border":{"width":"0px","style":"none"}},"className":"is-style-default"} -->
<div class="wp-block-column is-style-default" style="border-style:none;border-width:0px;padding-top:0;padding-right:0;padding-bottom:0;padding-left:0"><!-- wp:image {"id":121,"sizeSlug":"full","linkDestination":"none"} -->
<figure class="wp-block-image size-full"><img src="<?php echo esc_url( get_theme_file_uri() ) . '/assets/images/'; ?>t6.png" alt="" class="wp-image-121"/></figure>
<!-- /wp:image -->

<!-- wp:heading -->
<h2>Sharon Austin</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>CTO</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Successfully completed Project 8, demonstrating strong skills in cloud infrastructure and deployment using Amazon EKS.</p>
<!-- /wp:paragraph -->

<!-- wp:social-links {"iconColor":"lightgrey","iconColorValue":"#6C6C77","className":"is-style-logos-only"} -->
<ul class="wp-block-social-links has-icon-color is-style-logos-only"><!-- wp:social-link {"url":"#","service":"linkedin"} /--></ul>
<!-- /wp:social-links --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:group -->

<!-- wp:spacer {"height":"118px"} -->
<div style="height:118px" aria-hidden="true" class="wp-block-spacer"></div>
<!-- /wp:spacer --></div>
<!-- /wp:group -->
